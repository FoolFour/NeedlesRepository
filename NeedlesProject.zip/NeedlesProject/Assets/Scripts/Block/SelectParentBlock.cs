﻿using UnityEngine;

//エディタ上の動作を変えるだけのスクリプト

//シーンビューでオブジェクトをクリックしたとき
//子オブジェクトを選択するのではなく親オブジェクトを選択する
[SelectionBase]
public class SelectParentBlock : MonoBehaviour { }
